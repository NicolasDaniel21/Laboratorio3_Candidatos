package suites;

import cases.CandidatoTest;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;

@Suite
@SelectClasses({CandidatoTest.class})
public class AllTests {
	
	public AllTests() {
		Result result = JUnitCore.runClasses(CandidatoTest.class); // Executa a classe CandidatoTest
		
	    if (result.wasSuccessful()) {
	        System.out.println("Todos os testes passaram!");
	    } else {
	        System.out.println("Alguns testes falharam.");
	    }
	}
}