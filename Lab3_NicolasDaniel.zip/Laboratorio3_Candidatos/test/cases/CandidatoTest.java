package cases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;

import candidato.Candidato;

public class CandidatoTest {
	@Test
    public void testGetNome() {
        Candidato candidato = new Candidato("josé", 50, "Partido Dois", 60);
        assertEquals("josé", candidato.getNome());
    }

    @Test
    public void testSetNome() {
        Candidato candidato = new Candidato("mauro", 35, "Partido A", 500);
        assertEquals("mauro", candidato.getNome());
    }

    @Test
    public void testGetIdade() {
        Candidato candidato = new Candidato("João", 42, "Partido B", 400);
        assertEquals(42, candidato.getIdade());
    }

    @Test
    public void testSetIdade() {
        Candidato candidato = new Candidato("arthur", 78, "Partido C", 345);
        candidato.setIdade(40);
        assertEquals(40, candidato.getIdade());
    }

    @Test
    public void testGetPartido() {
        Candidato candidato = new Candidato("pedro", 30, "Partido D", 123);
        assertEquals("Partido D", candidato.getPartido());
    }

    @Test
    public void testSetPartido() {
        Candidato candidato = new Candidato("gabriel", 57, "Partido E", 534);
        candidato.setPartido("Partido H");
        assertEquals("Partido H", candidato.getPartido());
    }

    @Test
    public void testGetQuantidadeVotos() {
        Candidato candidato = new Candidato("leonardo", 99, "Partido idoso", 60);
        assertEquals(60, candidato.getQuantidadeVotos());
    }

    @Test
    public void testSetQuantidadeVotos() {
        Candidato candidato = new Candidato("nicolas", 20, "Partido vencedor", 10000);
        candidato.setQuantidadeVotos(12123);
        assertEquals(12123, candidato.getQuantidadeVotos());
    }
    
    @Test
    public void testComparacaoVotos() {
        Candidato candidato1 = new Candidato("Alice", 30, "Partido A", 500);
        Candidato candidato2 = new Candidato("Bob", 40, "Partido B", 700);
        Candidato candidato3 = new Candidato("Charlie", 35, "Partido C", 600);
        
        // Verificar se candidato2 tem mais votos que candidato1
        assertTrue(candidato2.getQuantidadeVotos() > candidato1.getQuantidadeVotos());
        
        // Verificar se candidato3 tem mais votos que candidato1
        assertTrue(candidato3.getQuantidadeVotos() > candidato1.getQuantidadeVotos());
        
        // Verificar se candidato2 tem mais votos que candidato3
        assertTrue(candidato2.getQuantidadeVotos() > candidato3.getQuantidadeVotos());
    }
}
