package candidato;

public class Candidato {
	private String nome, partido;
	private int quantidadeVotos, idade;
	
	public Candidato(String nome, int idade, String partido, int quantidadeVotos) {
		this.nome = nome;
		this.idade = idade;
		this.partido = partido;
		this.quantidadeVotos = quantidadeVotos;
	}
	
	@Override
	public String toString() {
		return "Candidato [nome=" + nome + ", partido=" + partido + ", quantidadeVotos=" + quantidadeVotos + ", idade="
				+ idade + "]";
	}

	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public int getIdade() {
		return idade;
	}
	
	public void setIdade(int idade) {
		this.idade = idade;
	}
	
	public String getPartido() {
		return partido;
	}
	
	public void setPartido(String partido) {
		this.partido = partido;
	}
	
	public int getQuantidadeVotos() {
		return quantidadeVotos;
	}
	
	public void setQuantidadeVotos(int quantidadeVotos) {
		this.quantidadeVotos = quantidadeVotos;
	}
}
