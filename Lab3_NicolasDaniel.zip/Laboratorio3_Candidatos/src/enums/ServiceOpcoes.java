package enums;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

import candidato.Candidato;

public class ServiceOpcoes {
	private static Scanner sc;
	private static List<Candidato> candidatos;
	
	public ServiceOpcoes() {
		sc = new Scanner(System.in);
		candidatos = new ArrayList<>();
	}
	
	public static int getOpcao() {
		return sc.nextInt();
	}
	
	public static void criarCandidato() {
		sc.nextLine();
		String nome;
		do {
			System.out.print("Nome: ");
			nome = sc.nextLine();
		}while(nome.length() <= 0);
		
		int idade = -1;
		do {
			System.out.print("Idade: ");
			idade = sc.nextInt();
		}while(idade <= 0);
		
		sc.nextLine();
		String partido;
		do {
			System.out.print("Partido: ");
			partido = sc.nextLine();
		}while(partido.length() <= 0);
		
		int votos = -1;
		do {
			System.out.print("Quantidade de votos: ");
			votos = sc.nextInt();
		}while(votos < 0);
		
		candidatos.add(new Candidato(nome, idade, partido, votos));
	}
	
	public static void exibirInformacoes() {
		if(!candidatos.isEmpty()) {
			// Contabilizando o total de votos
			int totalVotos = candidatos.stream().mapToInt(Candidato::getQuantidadeVotos).sum();
	        System.out.println("\nTotal de votos: " + totalVotos);
	        
	        // Calculando a média de votos
	        double mediaVotos = totalVotos / candidatos.size();
	        System.out.println("Média de votos: " + mediaVotos);
			
			// Ordenando por idade (mais jovem para mais velho)
			Collections.sort(candidatos, Comparator.comparingInt(Candidato::getIdade));
			
			// Exibindo candidato mais jovem e mais velho
			System.out.println("Candidato mais jovem: " + candidatos.get(0).toString());
			System.out.println("Candidato mais velho: " + candidatos.get(candidatos.size()-1).toString());
			
			// Ordenando por quantidade de votos (mais votado para menos votado)
	        Collections.sort(candidatos, Comparator.comparingInt(Candidato::getQuantidadeVotos).reversed());
	
	        // Exibindo candidato mais votado e menos votado
	        System.out.println("Candidato mais votado: " + candidatos.get(0).toString());
			System.out.println("Candidato menos votado: " + candidatos.get(candidatos.size()-1).toString());
		}else {
			System.out.println("\nNao ha candidatos no momento.");
		}
	}
	
	public static void exibirCandidatos() {

		if(!candidatos.isEmpty()) {
			System.out.println("\nExibindo todos os candidatos:");
			
			for (Candidato candidato : candidatos) {
				System.out.println(candidato.toString());
			}
		}
		else {
			System.out.println("\nNao ha candidatos na lista.");
		}
	}
}
