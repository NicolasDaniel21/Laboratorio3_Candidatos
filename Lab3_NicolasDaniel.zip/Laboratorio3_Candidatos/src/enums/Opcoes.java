package enums;

public enum Opcoes {
	ENCERRAR_PROGRAMA("Encerrar programa"),
    CRIAR_CANDIDATO("Criar candidato"),
    EXIBIR_INFORMACOES("Exibir informações"),
    EXIBIR_CANDIDATOS("Exibir candidatos");

    private final String descricao;

    Opcoes(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }

    public static void mostrarOpcoes() {
        int i = 0;
        System.out.println("");
        for (Opcoes opcao : values()) {
            System.out.println(i + ". " + opcao.getDescricao());
            i++;
        }
        System.out.print("Escolha uma das opcoes acima: ");
    }
}
