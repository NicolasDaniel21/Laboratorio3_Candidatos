package ui;
import java.util.InputMismatchException;

import enums.Opcoes;
import enums.ServiceOpcoes;

public class Menu {
	int opcao;
	ServiceOpcoes serviceOpcoes;
	
	public Menu() {
		opcao = -1;
		serviceOpcoes = new ServiceOpcoes();
	}

	public void iniciarPrograma()
	{
		System.out.println("Seja bem-vindo ao programa.");
		
		do {
			try {
				Opcoes.mostrarOpcoes();
				opcao = ServiceOpcoes.getOpcao();
				
				if(opcao < 0 || opcao >= Opcoes.values().length) { throw new InputMismatchException(); }
				
				if(Opcoes.values()[opcao] == Opcoes.CRIAR_CANDIDATO)
				{
					System.out.println("\nPreencha as seguintes informacoes do candidato:");
					ServiceOpcoes.criarCandidato();
				}
				else if(Opcoes.values()[opcao] == Opcoes.EXIBIR_INFORMACOES)
				{
					ServiceOpcoes.exibirInformacoes();
				}
				else if(Opcoes.values()[opcao] == Opcoes.EXIBIR_CANDIDATOS)
				{
					ServiceOpcoes.exibirCandidatos();
				}
			} catch(InputMismatchException e) {
				System.out.println("\nOpcao selecionada invalida.");
			}
		}while(Opcoes.values()[opcao] != Opcoes.ENCERRAR_PROGRAMA);
		
		System.out.println("\nPrograma encerrado!");
	}
}
