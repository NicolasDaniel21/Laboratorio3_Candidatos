package main;

import ui.Menu;

public class Main {

	public static void main(String[] args) {
			Menu ui = new Menu();
			ui.iniciarPrograma();
	}
}

